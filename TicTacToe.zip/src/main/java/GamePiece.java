public class GamePiece {
  public boolean isPlayer;

  public GamePiece(boolean isPlayer) {
    this.isPlayer = isPlayer;
  }

  public GamePiece() {
  }

  public String pieceToString() {
    if (isPlayer) {
      return "X";
    } else {
      return "O";
    }
  }
}