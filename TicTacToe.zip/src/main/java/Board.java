import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Board extends JFrame {
    protected GamePiece[] boardSlots = new GamePiece[9];
    private JButton[] buttons = new JButton[9];
    public UserInputObserver ui;

    public Board() {
        this.setTitle("Tic Tac Toe");
        this.setLayout(new GridLayout(3, 3));
        this.setSize(400, 400); // Set a larger size for the window
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close application on exit

        ui = new UserInputObserver(); // Initialize the UserInputObserver

        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton(" ");
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 120)); // Increase font size for better visibility
            buttons[i].setFocusPainted(false);
            buttons[i].setBackground(Color.LIGHT_GRAY); // Optional: Set a background color
            buttons[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 5)); // Optional: Add a border

            // Assign the button's index properly using the loop index
            buttons[i].addActionListener(new ButtonClickListener(i)); // Add an ActionListener
            add(buttons[i]);
        }

        this.setVisible(true);
        this.setLocationRelativeTo(null); // Center the window on the screen
    }

    private class ButtonClickListener implements ActionListener {
        private int index;

        public ButtonClickListener(int index) {
            this.index = index; // Store the index for use in actionPerformed
        }

        public void actionPerformed(ActionEvent e) {
            if (buttons[index].getText().equals(" ")) {
                ui.createInput(GameController.getInstance().isPlayerTurn, index); 
                buttons[index].setText(GameController.getInstance().passTurn());
            }
        }
    }

    public void placePiece(GamePiece piece, int location){
        boardSlots[location] = piece;
    }
    public GamePiece getPosition(int i){
        return boardSlots[i];
    }
}
