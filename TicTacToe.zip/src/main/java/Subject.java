import java.util.ArrayList;
import java.util.List;

public interface Subject{
  public List<Observer> obs = new ArrayList<Observer>();

  public void addObserver(Observer o);
  public void removeObserver(Observer o);
  public void notifyObservers();

  
}