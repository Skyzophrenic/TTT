public class GameController implements Observer {
  // Step 1: Create a private static instance of the class
  protected Board board;
  protected static GameController instance;
  protected boolean isPlayerTurn = true;
  protected PiecePool pool;

  // Step 2: Make the constructor private to prevent instantiation
  private GameController() {
    board = new Board();
    pool = new PiecePool();
  }

  // Step 3: Provide a public static method to get the instance
  public static GameController getInstance() {
    if (instance == null) {
      instance = new GameController();
    }
    return instance;
  }

  public String passTurn() {
    if (isPlayerTurn) {
      isPlayerTurn = !isPlayerTurn;
      return "X";
    } else {
      isPlayerTurn = !isPlayerTurn;
      return "O";
    }
  }

  public void update(InputCommand command) {
    System.out.println(command.isPlayer + "  " + command.targetLocation);
    // pull down game piece and into appropriate spot
    board.placePiece(pool.getPiece(command.isPlayer, command.targetLocation), command.targetLocation);
    // check win condition
    checkGameStatus();
    // go next turn

  }

  private boolean checkLine(int aIndex, int bIndex, int cIndex) {
      GamePiece a = board.getPosition(aIndex);
      GamePiece b = board.getPosition(bIndex);
      GamePiece c = board.getPosition(cIndex);
      return a != null && b != null && c != null && a.isPlayer == b.isPlayer && b.isPlayer == c.isPlayer;
  }
  
  public GameStatus checkGameStatus() {
      // Check rows, columns, and diagonals for a win
      for (int i = 0; i < 3; i++) {
          if (checkLine(i * 3, i * 3 + 1, i * 3 + 2)) { // Check rows
              GameStatus status = board.getPosition(i * 3).isPlayer ? GameStatus.WIN : GameStatus.LOSE;
              System.out.println("GAME END: " + status);
              return status;
          }
          if (checkLine(i, i + 3, i + 6)) { // Check columns
              GameStatus status = board.getPosition(i).isPlayer ? GameStatus.WIN : GameStatus.LOSE;
              System.out.println("GAME END: " + status);
              return status;
          }
      }
      if (checkLine(0, 4, 8)) { // Check diagonal
          GameStatus status = board.getPosition(0).isPlayer ? GameStatus.WIN : GameStatus.LOSE;
          System.out.println("GAME END: " + status);
          return status;
      }
      if (checkLine(2, 4, 6)) { // Check other diagonal
          GameStatus status = board.getPosition(2).isPlayer ? GameStatus.WIN : GameStatus.LOSE;
          System.out.println("GAME END: " + status);
          return status;
      }

      // Check for draw
      for (int i = 0; i < 9; i++) {
          if (board.getPosition(i) == null) {
              return GameStatus.CONTINUE; // There's still an empty slot
          }
      }

      System.out.println("GAME END: DRAW"); // Print draw message
      return GameStatus.DRAW; // No empty slots, and no winner
  }



  
}


